insert into �b���K�X��V2
values('facebook','aaaaa5246@aaaa.com','bbbbbbbbbb5462'),
	  ('stream','ccccccc55','dddddd123'),
	  ('discord','eeeehiu586','fffffff85246'),
	  ('Riot','Fudidj54682','abcdefg2564')
SELECT TOP (1000)[app名字]
      ,[帳號]
      ,[密碼]
  FROM [期末報告].[dbo].[帳號密碼表V2]
